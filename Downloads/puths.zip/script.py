import pydirectinput
import pyautogui
import time
import sys
import win32gui
import win32con
import pyrobloxbot
import requests
import pyscreeze
import keyboard
import subprocess
pyscreeze.USE_IMAGE_NOT_FOUND_EXCEPTION = False
pyautogui.PAUSE = 0
pyautogui.MINIMUM_DURATION = 0
pyautogui.MINIMUM_SLEEP = 0
pyautogui.FAILSAFE = False
pydirectinput.PAUSE = 0.0

win_region = None

wrong = []

puthsCheckComplete = False

text = 'input-answer.png'

puthsCheck = False

paused = False
#TURNING THIS ON (with left alt) WILL MAKE THE SCRIPT GO NONSTOP UNLESS left alt IS PRESSED.
grind_mode = True

try:
    count = int(sys.argv[-1])
except ValueError:
    count = 0

def wait_for_image(image_path, timeout=10):
    """Waits for an image to appear on screen for up to `timeout` seconds."""
    start_time = time.time()
    while time.time() - start_time < timeout:
        # attempt to locate the image on the screen
        location = pyautogui.locateOnScreen(image_path, confidence=0.7)
        if location is not None:
            return location
    time.sleep(0.1) 
    return None

def focus_roblox():
    hwnd = win32gui.FindWindow(None, "Roblox")
    if hwnd != 0:
        win32gui.ShowWindow(hwnd, win32con.SW_RESTORE)
        win32gui.SetForegroundWindow(hwnd)
        print("Roblox window focused!")
        time.sleep(0.1)
        rect = win32gui.GetWindowRect(hwnd)
        win_x = rect[0]
        win_y = rect[1]
        win_w = rect[2] - rect[0]
        win_h = rect[3] - rect[1]
        global win_region
        win_region = (win_x, win_y, win_w, win_h)
        global x 
        global y
        x = rect[0] + 500
        y = rect[1] + 500
        pydirectinput.doubleClick(x, y)
    else:
        print("Roblox window not found.")
        sys.exit()

def check():
    global puthsCheckComplete
    if puthsCheck == False:
            wrong.append(line)
            pydirectinput.press("2")
            wait_for_image(text, timeout=10)
            pydirectinput.press("2")
            puthsCheckComplete = True
    else:
            print("GG")
            with open("epsteinfile.txt", "a") as f:
                f.write(line)
            raise pydirectinput.FailSafeException
    
def toggle_grind():
    global grind_mode
    if grind_mode:
        grind_mode = False
        print("GRIND-MODE DISABLED.")
    else:
        grind_mode = True
        print("GRIND-MODE ENABLED.")

keyboard.add_hotkey('left alt', toggle_grind)

try:
    if grind_mode == True:
        print("GRIND-MODE ACTIVATED.")
    focus_roblox()
    print("Script activating in 5 seconds.")
    time.sleep(5)
    print("Script activated. Mouse in top left to exit.")
    pydirectinput.press('2')
    wait_for_image(text, timeout=10)
    pydirectinput.press("2")
    pyrobloxbot.enable_ui_navigation()
    
    with open("oxford.txt", "r", encoding="utf-8") as file:
        for line in file:
            puthsCheckComplete = False
            if  wait_for_image(text, timeout=10) is None:
                print("Textbox not found.")
                raise pydirectinput.FailSafeException
            else:
                pyrobloxbot.ui_navigate("right", "right", "right", "down", "click")
                time.sleep(0.03)
                pyautogui.write(line.strip(), 0.025)
                pyrobloxbot.ui_navigate("click", "down", "click")
                paused = True
            while paused == True:
                response = requests.get('https://inventory.roblox.com/v1/users/2371365926/items/2/1879307814563194/is-owned')
                puthsCheck = response.text.strip().lower() == "true"
                time.sleep(0.05)
                check()
                if puthsCheckComplete == True:
                    paused = not paused
                    if paused == False:
                        break
            time.sleep(0.1)
except (pydirectinput.FailSafeException):
    pyautogui.moveTo(x, y)
    pyrobloxbot.disable_ui_navigation()
    with open("wrong.txt", "a") as wrongFile:
        wrongFile.writelines(word for word in wrong)
    with open("wrong.txt", "r") as wrongFile:
        wrongLines = {line.rstrip("\n") for line in wrongFile}
    with open("oxford.txt", "r", encoding="utf-8") as fileAgain:
        result = [
            line
            for line in fileAgain
            if line.rstrip("\n") not in wrongLines
        ]
    with open("oxford.txt", "w", encoding="utf-8") as f:
        f.writelines(result)
        print("File edited and saved!")
    open("wrong.txt", "w").close()
    if count == 3:
        pyrobloxbot.hold_key("w", duration=2)
        count = int(count) - 3
finally:
    if len(sys.argv) > 1 and sys.argv[-1].isdigit():
        base_args = sys.argv[:-1]
    else:
        base_args = sys.argv
    cmd = [sys.executable, f"script.py"] + [str(arg) for arg in base_args[1:]]
    if grind_mode == True:
        count = int(count) + 1
        cmdGrind = cmd + [str(count)]
        time.sleep(1)
        subprocess.Popen(cmdGrind)
        sys.exit(0)
    if pyautogui.prompt(text='if you want to continue just press ok', title='End script?' , default='') is None:
        print("Ending.")
        sys.exit(0)
    else:
        print("Restarting.")
        time.sleep(1)
        subprocess.Popen(cmd)
        sys.exit(0)
        
if_you_delete_this_your_gay = "Script made by AutoKnight (please dont remove)"